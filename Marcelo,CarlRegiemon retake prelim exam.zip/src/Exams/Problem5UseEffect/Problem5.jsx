import { useEffect, useRef, useState } from 'react';
import Loading from './Problem5Components/Loading';

export default function Problem5() {
  const [isLoading, setIsLoading] = useState(true);
  const [userStatus, setUserStatus] = useState('User is idle...');
  const typingTimeoutRef = useRef(null);

  
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 3000);

    return () => clearTimeout(timer); 
  }, []);

  
  const handleInputChange = () => {
    setUserStatus('User is typing...');
    
    
    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }

   
    typingTimeoutRef.current = setTimeout(() => {
      setUserStatus('User is idle...');
    }, 1000); 
  };

  return (
    <>
      {isLoading ? (
        <Loading />
      ) : (
        <>
          <div style={{ display: 'block' }}>
            Input: <input type='text' onChange={handleInputChange} />
            <p>{userStatus}</p>
          </div>
        </>
      )}
    </>
  );
}