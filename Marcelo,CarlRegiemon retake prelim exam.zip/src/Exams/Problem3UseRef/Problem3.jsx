import React, { useState } from 'react';

function Problem4() {
  const [formData, setFormData] = useState({
    name: '',
    yearLevel: '',
    course: '',
  });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();   

    // Handle form submission here, e.g., send data to   
 server
    console.log('Form Data:', formData);
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label>Name:</label>
        <input
          type="text"
          name="name"
          value={formData.name}
          onChange={handleChange}
        />
      </div>

      <div>
        <label>Year   
 Level:</label>
        <div>
          <input
            type="radio"
            name="yearLevel"
            value="First Year"
            checked={formData.yearLevel === 'First Year'}
            onChange={handleChange}
          />
          <label>First Year</label>
        </div>
        {/* ... other year level radio buttons ... */}
      </div>

      <div>
        <label>Course:</label>
        <select
          name="course"
          value={formData.course}
          onChange={handleChange}
        >
          <option value="BSCS">BSCS</option>
          <option value="BSIT">BSIT</option>
          <option value="BSIS">BSIS</option>
        </select>
      </div>

      <button type="submit">Submit</button>
      <p>Form Data: {JSON.stringify(formData)}</p>
    </form>
  );
}

export default Problem4;