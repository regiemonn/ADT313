import React from 'react';

const StudentInfo = ({ name, course, section }) => {
    return (
        <div>
            <h2>Student Information</h2>
            <p><strong>Name:</strong> {name}</p>
            <p><strong>Course:</strong> {course}</p>
            <p><strong>Section:</strong> {section}</p>
        </div>
    );
};

export default StudentInfo;